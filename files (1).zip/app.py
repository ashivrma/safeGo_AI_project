"""
SafeGo AI - Flask Backend
Handles citizen registration, face storage, and alert coordination.
"""

from flask import Flask, request, jsonify, send_from_directory, render_template_string
from flask_cors import CORS
import sqlite3
import os
import base64
import uuid
import json
from datetime import datetime
import face_recognition
import numpy as np
import pickle

app = Flask(__name__)
CORS(app)

DB_PATH = "safego.db"
FACES_DIR = "registered_faces"
os.makedirs(FACES_DIR, exist_ok=True)

# -----------------------------------------------------------------------
# DATABASE SETUP
# -----------------------------------------------------------------------

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS citizens (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            phone TEXT,
            email TEXT NOT NULL,
            emergency_contact_name TEXT,
            emergency_contact_email TEXT NOT NULL,
            emergency_contact_phone TEXT,
            address TEXT,
            face_image_path TEXT,
            face_encoding BLOB,
            registered_at TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS alerts (
            id TEXT PRIMARY KEY,
            citizen_id TEXT,
            citizen_name TEXT,
            camera_location TEXT,
            screenshot_path TEXT,
            alert_sent_to TEXT,
            alert_time TEXT,
            status TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()


# -----------------------------------------------------------------------
# HELPER FUNCTIONS
# -----------------------------------------------------------------------

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def load_all_face_encodings():
    """Load all registered face encodings from database."""
    conn = get_db()
    rows = conn.execute("SELECT id, name, face_encoding FROM citizens WHERE face_encoding IS NOT NULL").fetchall()
    conn.close()
    
    encodings = []
    for row in rows:
        if row['face_encoding']:
            encoding = pickle.loads(row['face_encoding'])
            encodings.append({
                'id': row['id'],
                'name': row['name'],
                'encoding': encoding
            })
    return encodings


# -----------------------------------------------------------------------
# API ROUTES
# -----------------------------------------------------------------------

@app.route('/api/register', methods=['POST'])
def register_citizen():
    """Register a new citizen with photo and emergency contact."""
    try:
        data = request.json
        
        required = ['name', 'email', 'emergency_contact_email', 'face_image_base64']
        for field in required:
            if not data.get(field):
                return jsonify({'success': False, 'error': f'Missing field: {field}'}), 400
        
        # Decode and process the face image
        face_b64 = data['face_image_base64']
        if ',' in face_b64:
            face_b64 = face_b64.split(',')[1]
        
        img_bytes = base64.b64decode(face_b64)
        
        # Save image
        citizen_id = str(uuid.uuid4())
        image_filename = f"{citizen_id}.jpg"
        image_path = os.path.join(FACES_DIR, image_filename)
        
        with open(image_path, 'wb') as f:
            f.write(img_bytes)
        
        # Generate face encoding — try HOG first, then upsample
        image = face_recognition.load_image_file(image_path)
        
        face_locations = face_recognition.face_locations(image, model="hog")
        if not face_locations:
            face_locations = face_recognition.face_locations(
                image, number_of_times_to_upsample=2, model="hog"
            )

        if not face_locations:
            os.remove(image_path)
            return jsonify({'success': False, 'error': 'No face detected in the uploaded photo. Please use a clear, well-lit frontal face photo.'}), 400

        # num_jitters=5 gives a more robust encoding (slower but worth it at registration)
        face_encs = face_recognition.face_encodings(image, face_locations, num_jitters=5)
        
        if not face_encs:
            os.remove(image_path)
            return jsonify({'success': False, 'error': 'Could not encode face. Please try a different photo.'}), 400
        
        face_encoding_blob = pickle.dumps(face_encs[0])
        
        # Save to database
        conn = get_db()
        conn.execute('''
            INSERT INTO citizens 
            (id, name, phone, email, emergency_contact_name, emergency_contact_email, 
             emergency_contact_phone, address, face_image_path, face_encoding, registered_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            citizen_id,
            data['name'],
            data.get('phone', ''),
            data['email'],
            data.get('emergency_contact_name', ''),
            data['emergency_contact_email'],
            data.get('emergency_contact_phone', ''),
            data.get('address', ''),
            image_path,
            face_encoding_blob,
            datetime.now().isoformat()
        ))
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'message': f'Successfully registered {data["name"]}! You are now protected by SafeGo AI.',
            'citizen_id': citizen_id
        })
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/identify', methods=['POST'])
def identify_face():
    """
    Identify a face from a frame image. Called by the detection script.
    
    Improvements for reliability:
    - Tries HOG model first (fast), falls back to upsampling if no face found
    - Tolerance raised to 0.65 (real-world webcam friendly)
    - Resizes large frames for faster processing
    - Enhances contrast before detection
    - Returns best match distance in response for debugging
    """
    try:
        data = request.json
        face_b64 = data.get('face_image_base64', '')

        if ',' in face_b64:
            face_b64 = face_b64.split(',')[1]

        img_bytes = base64.b64decode(face_b64)

        temp_path = f"temp_{uuid.uuid4()}.jpg"
        with open(temp_path, 'wb') as f:
            f.write(img_bytes)

        try:
            unknown_image = face_recognition.load_image_file(temp_path)

            # ── Resize if image is too large (speeds up processing) ──────────
            h, w = unknown_image.shape[:2]
            if w > 1280:
                scale = 1280 / w
                unknown_image = np.array(
                    face_recognition.load_image_file(temp_path)
                )
                import cv2 as _cv2
                unknown_image = _cv2.resize(unknown_image, (int(w*scale), int(h*scale)))

            # ── Try HOG first (fast), then upsample if no face found ─────────
            unknown_locations = face_recognition.face_locations(unknown_image, model="hog")

            if not unknown_locations:
                print("[Identify] HOG found no face, trying with upsampling...")
                unknown_locations = face_recognition.face_locations(
                    unknown_image, number_of_times_to_upsample=2, model="hog"
                )

            if not unknown_locations:
                print("[Identify] Still no face found. Trying CNN model...")
                unknown_locations = face_recognition.face_locations(unknown_image, model="cnn")

            if not unknown_locations:
                print("[Identify] No face detected in frame after all attempts.")
                return jsonify({'identified': False, 'reason': 'No face detected — ensure face is clearly visible and well-lit'})

            print(f"[Identify] Found {len(unknown_locations)} face(s) in frame.")

            # ── Encode detected faces with more jitters for accuracy ──────────
            unknown_encodings = face_recognition.face_encodings(
                unknown_image, unknown_locations, num_jitters=3
            )

            all_known = load_all_face_encodings()

            if not all_known:
                return jsonify({'identified': False, 'reason': 'No registered citizens in database'})

            known_encodings = [p['encoding'] for p in all_known]

            best_overall_distance = 1.0
            best_overall_match = None

            for unknown_enc in unknown_encodings:
                distances = face_recognition.face_distance(known_encodings, unknown_enc)
                best_idx  = int(np.argmin(distances))
                best_dist = float(distances[best_idx])

                print(f"[Identify] Best match distance: {best_dist:.4f} (threshold: 0.65)")

                if best_dist < best_overall_distance:
                    best_overall_distance = best_dist
                    best_overall_match    = all_known[best_idx]

            # ── Tolerance: 0.65 works well for real-world webcam conditions ──
            TOLERANCE = 0.65

            if best_overall_match and best_overall_distance < TOLERANCE:
                conn = get_db()
                citizen = conn.execute(
                    "SELECT * FROM citizens WHERE id = ?", (best_overall_match['id'],)
                ).fetchone()
                conn.close()

                print(f"[Identify] ✅ Matched: {citizen['name']} (distance: {best_overall_distance:.4f})")

                return jsonify({
                    'identified':              True,
                    'citizen_id':              citizen['id'],
                    'name':                    citizen['name'],
                    'email':                   citizen['email'],
                    'phone':                   citizen['phone'],
                    'emergency_contact_name':  citizen['emergency_contact_name'],
                    'emergency_contact_email': citizen['emergency_contact_email'],
                    'emergency_contact_phone': citizen['emergency_contact_phone'],
                    'confidence':              round(1.0 - best_overall_distance, 3),
                    'distance':                round(best_overall_distance, 4)
                })

            print(f"[Identify] ❌ No match. Best distance was {best_overall_distance:.4f} (needed < {TOLERANCE})")
            return jsonify({
                'identified': False,
                'reason':     'No match found — person not registered',
                'best_distance': round(best_overall_distance, 4),
                'tip': 'If this is a registered person, try re-registering with better lighting'
            })

        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

    except Exception as e:
        print(f"[Identify] Exception: {e}")
        return jsonify({'identified': False, 'error': str(e)}), 500


@app.route('/api/log_alert', methods=['POST'])
def log_alert():
    """Log an alert event to the database."""
    try:
        data = request.json
        alert_id = str(uuid.uuid4())
        
        conn = get_db()
        conn.execute('''
            INSERT INTO alerts (id, citizen_id, citizen_name, camera_location, screenshot_path, alert_sent_to, alert_time, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            alert_id,
            data.get('citizen_id', 'UNKNOWN'),
            data.get('citizen_name', 'Unregistered Person'),
            data.get('camera_location', 'Unknown Location'),
            data.get('screenshot_path', ''),
            data.get('alert_sent_to', ''),
            datetime.now().isoformat(),
            'SENT'
        ))
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'alert_id': alert_id})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/stats', methods=['GET'])
def get_stats():
    """Get system statistics for the dashboard."""
    conn = get_db()
    total_citizens = conn.execute("SELECT COUNT(*) FROM citizens").fetchone()[0]
    total_alerts = conn.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
    recent_alerts = conn.execute(
        "SELECT * FROM alerts ORDER BY alert_time DESC LIMIT 5"
    ).fetchall()
    conn.close()
    
    return jsonify({
        'total_registered': total_citizens,
        'total_alerts': total_alerts,
        'recent_alerts': [dict(a) for a in recent_alerts]
    })


@app.route('/')
def index():
    return send_from_directory('.', 'index.html')


if __name__ == '__main__':
    print("SafeGo AI Backend running on http://localhost:5000")
    app.run(debug=True, port=5000)
